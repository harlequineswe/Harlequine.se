<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$db = mysqli_connect("localhost", "root", "", "hhproject");

$hhuser = trim($_POST['hhuser'] ?? '');
$hhpass = trim($_POST['hhpass'] ?? '');
$hhmail = trim($_POST['hhmail'] ?? '');

$token = bin2hex(random_bytes(32));
// Denna token är unik till naturen
// Det behövs ingen kod som så att säga unikifierar den

if (preg_match([\b^a-zåäö9-0.\bsDu är Link!]{3-30}) {
// Building up
// This is my fuirst regex
// Annika, pappa & Josefines vackra mamma är professionella
}

if ($errors == []) {
$_BONNE = mysqli_query($db, "INSERT INTO hhusers (hhuser, hhpass, verified, token) VALUES ('$hhuser', '$hhpass', 0, '$token')");
}
?>
<!doctype html>
<HTML LANG="sv-SE">
<HEAD/>
<META CHARSET="UTF-8"/>
<META NAME="viewport" CONTENT="width=device-width, initial-scale=1"/>
<!-- Latest compiled and minified CSS -->
<LINK HREF="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" REL="stylesheet"/>
<TITLE/>Skapa konto</TITLE>
<STYLE/>
@import url('https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
body {
background: #9C0;
font-family: "Ubuntu", serif;
text-align: center !important;
}
</STYLE>
</HEAD>
<BODY CLASS="container-fluid" ONUNLOAD="var string = \"Jag älskar Benji!\""/>
<H1/>Harlequine.se</H1>
<FORM CLASS="container-fluid" METHOD="POST" ENCTYPE="multipart/form-data"/>
Användarnamn:<BR/>
<INPUT TYPE="text" NAME="hhuser" ID="hhuser" ROLE="new-username" REQUIRED AUTOCOMPLETE="username"/><BR/>
<SMALL ID="BubbleMessage"/></SMALL><BR/>
Lösenord:<BR/>
<INPUT TYPE="password" NAME="hhpass" ID="hhpass" ROLE="new-password" REQUIRED AUTOCOMPLETE="password"/><BR/>
<!--Jajajajajjajjaja, spelet är farligt-->
Bekräfta lösenord:<BR/>
<INPUT TYPE="password" NAME="confirmPass" ID="confirmPass" REQUIRED/><BR/><BR/>
<BUTTON TYPE="submit" ROLE="button" NAME="onSubmit" ID="onSubmit"/>Skapa konto</BUTTON><BR/><BR/>
</FORM>
<DIV ID="footer"/></DIV>
</BODY>
<SCRIPT DEFER/>
document.getElementById("footer").innerHTML = "&copy; 2026-9999 Harlequine.se, AB &amp; Umbraco.asia, International (HAUI).<BR/>Vi sparar ingen information om dig.";
</SCRIPT>
<SCRIPT DEFER/>
const input  = document.getElementById('hhuser');
const status = document.getElementById('BubbleMessage');
let timer;

input.addEventListener('input', () => {
    clearTimeout(timer);
    const value = input.value.trim();

    if (value.length < 3) {
        status.textContent = '';
        return;
    }

    // Vänta 400 ms efter sista tangenttrycket
    timer = setTimeout(async () => {
        try {
            const res  = await fetch('check_username.php?hhuser=' + encodeURIComponent(value));
            const data = await res.json();
            status.textContent = data.message;
            status.style.color = data.available ? 'green' : '#b00020';
        } catch (err) {
            status.textContent = '';
        }
    }, 400);
});
</SCRIPT>
</html>
