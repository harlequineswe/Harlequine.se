CREATE TABLE IF NOT EXISTS hhusers (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    hhuser        VARCHAR(50)  NOT NULL UNIQUE,
    hhmail        VARCHAR(255) NOT NULL UNIQUE,
    hhpass        VARCHAR(255) NOT NULL,          -- password_hash()
    verified      TINYINT(1)   NOT NULL DEFAULT 0,
    token_hash    CHAR(64)     NULL,              -- sha256 av aktiveringstoken
    token_expires DATETIME     NULL,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4;
