<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$db = mysqli_connect("localhost", "root", "", "hhproject");

header('Content-Type: application/json; charset=utf-8');

$hhuser = trim($_GET['hhuser'] ?? '');

if (!preg_match('/^[\p{L}0-9_.-]{3,50}$/u', $hhuser)) {
    echo json_encode(['available' => false, 'message' => 'Ogiltigt användarnamn.']);
    exit;
}

$stmt = $db->prepare('SELECT 1 FROM hhusers WHERE hhuser = ?');
$stmt->bind_param('s', $hhuser);
$stmt->execute();
$taken = $stmt->get_result()->num_rows > 0;

echo json_encode([
    'available' => !$taken,
    'message'   => $taken ? '✗ Upptaget!' : '✓ Ledigt!',
]);
